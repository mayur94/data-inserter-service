package com.data.inserter.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataInserterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataInserterServiceApplication.class, args);
	}

}
